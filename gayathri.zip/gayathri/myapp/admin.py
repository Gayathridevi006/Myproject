from django.contrib import admin
from .models import todoItem


admin.site.register(todoItem)
# Register your models here.
