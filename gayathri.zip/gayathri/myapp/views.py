from django.shortcuts import render, HttpResponse
from .models import todoItem

def home(requests):
    return render(requests, "home.html")
    # return HttpResponse("heloooo world!!!!!")

def todos(requests):
    items = todoItem.objects.all()
    return render(requests, "todo.html", {"todos": items})